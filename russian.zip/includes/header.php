<?php if($folderRoot != "isMain"){header("location:../index.php");}?>
<!DOCTYPE HTML>
<html xmlns:fb="http://www.facebook.com/2008/fbml">
<head>