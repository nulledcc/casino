<?php if($folderRoot != "isMain"){header("location:../index.php");}?>
<div id="footer">&copy; 2013 artxaker</div>